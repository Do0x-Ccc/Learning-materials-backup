#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from AttribDict import AttribDict
from libs.DBHelper import DBHelper

conf = AttribDict()

###mysql配置
host = '192.168.50.153'
user = 'root'
database = 'aveai'
password = '7ujm*IK<'
port = 3306

##实例化
mdb = DBHelper(host, user, database, password, port)

#####请求配置
conf.COOKIE = 'AWSALBTG=9Ici+KedhnnQU8viFon6RJ6tBR01MK9Dkpyh0L6l97nGtADpE4KW4diMZ0aJ6d8kiiTf5CDxeWRwSlZQAR/JWhxWSyTIxAoqYHGYVJOwU1/X7vyb6BDPSG+Mnuhty4C1CihsXHTiJdHmfHZdW57A0mAa+gmVPiES4CcbvqLlanI9MnhpQ9w=;'
#####XIP（模拟IP）
conf.XIP = '139.99.237.178'
# 参数 X-Auth
conf.AUTH = '11add2556600a202e136d69ce31917361654139521694166407'

###爬取列表的URL
conf.POOL_URL = 'https://api.opencc.xyz/v1api/v2/pairs?pageNO=1&pageSize=20&sort=created_at&direction=desc&chain=bsc&minPoolSize=500&amm='


###TOKENS 的URL，合约变量在fetchall方法中更换
conf.TOKEN_URL = 'https://api.opencc.xyz/v1api/v2/tokens/{}-{}'
