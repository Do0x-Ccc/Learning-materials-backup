#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import ast
import time
from urllib.parse import urlparse

from libs.DBHelper import DBHelper
from libs.MyRequest import getRequest, getHunterInfo
from settings import conf, mdb


def resultHandler(reponse, target_token):
    newDICT = ast.literal_eval(reponse['data'])
    result = newDICT['token']
    remark = ''
    if 'appendix' in result.keys():
        appendix_json = ast.literal_eval(result['appendix'])
        website = appendix_json['website']
        if (website is not None and len(website) > 1):
            if "/" in website:
                result = urlparse(website)
                result = result.netloc.split('.')
                domain = result[-2] + "." + result[-1]
            else:
                domain = website
            print("查询域名:  " + domain)
            hunter_data = getHunterInfo(domain)
            country = hunter_data[0]
            port = hunter_data[1]
            finger = hunter_data[2]
            remarks = hunter_data[3]
            mdb.update(target_token, website, country, port, finger, remarks)
    else:
        remark = "website为空，无hunter查询信息"
        mdb.update(target_token, '', '', '', '', remark)

    print("----- %s update ok, %s ----- " % (target_token, remark))


def fetchall():
    allData = mdb.getHunter()
    for data in allData:
        try:
            contract = data['target_token']
            chain = data['chain']
            ##合约变量
            URL = conf.TOKEN_URL.format(contract, chain)
            result = getRequest(URL)
            resultHandler(result, contract)
            time.sleep(2)
        except Exception as e:
            print('fetchall get avi info error:' + str(e))
    print("----- all data check finished ----- ")


if __name__ == "__main__":
    fetchall()
    mdb.close()
