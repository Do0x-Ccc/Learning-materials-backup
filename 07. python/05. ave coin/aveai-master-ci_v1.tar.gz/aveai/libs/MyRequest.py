#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import base64

import requests

from settings import conf


def get_headers():
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,zh-TW;q=0.7',
        'Content-Type': 'application/json;charset=UTF-8',
        'X-Auth': conf.AUTH,
        'Cookie': conf.COOKIE,
        'X-Forwarded-For': conf.XIP,
        'X-Originating-IP': conf.XIP,
        'X-Remote-Addr': conf.XIP,
        'X-Remote-IP': conf.XIP,
        'WL-Proxy-Client-IP': conf.XIP,
    }
    return headers


def postRequest(myurl, data):
    try:
        conn = requests.session()
        res = conn.post(url=myurl, params=data, headers=get_headers(), timeout=10)
        if ((res is not None) and (res.status_code == 200)):
            return res.text
    except Exception as e:
        print('error' + str(e))
    return '-1'


def getRequest(myurl):
    try:
        conn = requests.session()
        res = conn.get(url=myurl, params=None, headers=get_headers(), timeout=10)
        if ((res is not None) and (res.status_code == 200)):
            return res.json()
    except Exception as e:
        print('error' + str(e))
    return '-1'

def getHunterInfo(domain):
    key = "ecfbffe0ab717143186a43bd487579b8962e8eb292d0319a92207434a49e3758"
    search = domain
    search = base64.urlsafe_b64encode(search.encode("utf-8"))
    search = search.decode('utf-8')
    url = "https://hunter.qianxin.com/openApi/search?api-key={}&search={}&page=1&page_size=20&is_web=1&status_code=200".format(key,search)
    print("Hunter api:    "+url)
    reps = requests.get(url=url).json()
    arr = reps['data']['arr']

    countrylist = []
    portlist    = []
    cpanellist  = []

    if arr != None:
        for i in arr:
            country = i['country']
            port    = i['port']
            component = i['component']
            countrylist.append(country)
            portlist.append(port)

            if component != None:
                for i in component:
                    cpanel = i['name']
                    cpanellist.append(cpanel)
    else:
        return ["","","","hunter查询无信息"]

    new_countrylist = []
    [	new_countrylist.append(i) for i in countrylist if i not in new_countrylist	]
    new_portlist = []
    [	new_portlist.append(i) for i in portlist if i not in new_portlist	]
    new_cpanellist = []
    [	new_cpanellist.append(i) for i in cpanellist if i not in new_cpanellist	]

    countrystr = ",".join(new_countrylist)
    portstr =",".join('%s' %id for id in new_portlist)
    cpanelstr  = ",".join(new_cpanellist)

    print("域名: {} 端口: {} 国家: {} 指纹: {}".format(domain,portstr,countrystr,cpanelstr))

    if "cPanel" in cpanellist or "Cloudflare" in cpanellist or "2096" in portlist or "2095" in portlist :
        print("pass")
        return ["","","","cdn or Cloudflare or cpanel"]

    elif "BaoTa 宝塔面板 Interface Prompt" in cpanellist:
        cpanelstr = "BaoTa 宝塔面板"
        return [countrystr,portstr,cpanelstr,"宝塔面板"]
    elif "中国" in countrylist or  "美国" in countrylist or  "新加坡" in countrylist:
        return [countrystr,portstr,cpanelstr,"国家符合要求"]
    else:
        return [" "," "," ","待确认"]