/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.50.153
 Source Server Type    : MariaDB
 Source Server Version : 100510
 Source Host           : 192.168.50.153:3306
 Source Schema         : scott

 Target Server Type    : MariaDB
 Target Server Version : 100510
 File Encoding         : 65001

 Date: 02/06/2022 15:06:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_aves
-- ----------------------------
DROP TABLE IF EXISTS `sys_aves`;
CREATE TABLE `sys_aves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pair` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pair_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createTime` datetime NOT NULL,
  `saveTime` datetime DEFAULT current_timestamp(),
  `website` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(4) DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
