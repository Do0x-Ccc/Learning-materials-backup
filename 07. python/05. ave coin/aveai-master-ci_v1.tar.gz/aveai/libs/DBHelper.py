#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import datetime
import pymysql


class DBHelper:
    def __init__(self, host, user, database, password, port):
        self.connect_db(host, user, database, password, port)

    def select(self, sql, one=True):
        self.cursor.execute(sql)
        if one:
            return self.cursor.fetchone()
        else:
            return self.cursor.fetchall()

    def close(self):
        self.cursor.close()
        self.conn.close()

    ##
    def save(self, mlist):
        if (mlist is None or len(mlist) < 1):
            return
        sql = "INSERT INTO `sys_aves`(`target_token`,`pair`,`chain`,`pair_name`,`createTime`) VALUES (%s, %s, %s, %s, %s);"
        try:
            self.conn.begin()
            self.cursor.executemany(sql, mlist)
            self.conn.commit()
        except Exception as e:
            print("SAVE Error:" + str(e))
            self.conn.rollback()

    def update(self, target_token, website, country, port, finger, remarks):
        sql = "update `sys_aves` set `website`='%s', `country`='%s', `port`='%s', `finger`='%s',`remarks`='%s',`status`=1 where target_token='%s';" % (
            website, country, port, finger, remarks, target_token)
        try:
            self.conn.begin()
            self.cursor.execute(sql)
            self.conn.commit()
        except Exception as e:
            print("SAVE Error:" + str(e))
            self.conn.rollback()

    def getHunter(self):
        result = None
        try:
            sql = "select * from sys_aves where status=0;"
            result = self.select(sql, False)
        except Exception as e:
            print("SAVE Error:" + str(e))
        return result

    def isInDB(self, target_token):
        sql = "SELECT count(id) as total from sys_aves where  target_token='%s';" % target_token
        count = 1
        try:
            result = self.select(sql)
            count = result['total']
        except Exception as e:
            print("SAVE Error:" + str(e))
        return count

    def connect_db(self, host, user, database, password, port):
        self.conn = pymysql.connect(host=host, user=user,
                                    password=password, database=database,
                                    port=port, charset="utf8")
        self.cursor = self.conn.cursor(cursor=pymysql.cursors.DictCursor)
