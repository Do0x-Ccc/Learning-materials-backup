

环境安装：

    pip install -r requirement.txt


配置（可不动）:

    settings.py

 
Hunter 信息获取命令:
    
    python3 hunter.py -c tron


爬虫列表 信息获取命令:

    python3 spider.py -c tron