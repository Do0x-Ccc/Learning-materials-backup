SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_aves_tron
-- ----------------------------
DROP TABLE IF EXISTS `sys_aves_tron`;
CREATE TABLE `sys_aves_tron` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `target_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                 `pair` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                 `chain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                 `pair_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                 `createTime` datetime NOT NULL,
                                 `saveTime` datetime DEFAULT CURRENT_TIMESTAMP,
                                 `website` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `finger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `status` int(4) DEFAULT '0',
                                 `comments` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 `comments1` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                 PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
