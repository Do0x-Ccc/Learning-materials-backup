#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import optparse
import sys
from settings import mdb


def cmdLineParser():
    """
    This function parses the command line parameters and arguments
    """
    parser = optparse.OptionParser(usage="python3 spider.py -c tron")
    # engine
    parser.add_option('-c', '--chain', dest='chain', type='string', help='chain of name',
                      default="bsc")

    (options, args) = parser.parse_args()
    # target
    if (len(options.chain) < 1):
        parser.print_help()
        sys.exit()
    return options


def initOptions():
    options = cmdLineParser()
    chain = options.chain
    mdb.setTbName(chain)
