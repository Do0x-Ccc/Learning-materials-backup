#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from AttribDict import AttribDict
from libs.DBHelper import DBHelper

conf = AttribDict()
###mysql配置
host = '192.168.50.153'
user = 'root'
database = 'aveai'
password = '7ujm*IK<'
port = 3306


##实例化
mdb = DBHelper(host, user, database, password, port)

#####请求配置
conf.COOKIE = 'AWSALBTG=69QcffyFHGmLeMkE3TsRSYI/cm9GcPCkCztdxNi/Lk9a0foEvF00ESn7wI5rV7fPEoNSFO4r4v4jzoZfxKmast76pVcBq6aCyDRW4LmlpASuf4brdDEjEbucrTNm+StNoCRFGF2UG8vzXrGBa6b8B0ApB7M81t+Txqn6vY2RS2pQYh46xFY=;'
#####XIP（模拟IP）
conf.XIP = '43.249.36.83'
# 参数 X-Auth
conf.AUTH = 'd3ce65db88e29c156f16d90a53bed4391655876939221597832'

###爬取列表的URL
conf.POOL_URL = 'https://api.opencc.xyz/v1api/v2/pairs?pageNO=1&pageSize=1000&sort=created_at&direction=desc&chain={}&minPoolSize=500&amm='

###TOKENS 的URL
conf.TOKEN_URL = 'https://api.opencc.xyz/v1api/v2/tokens/{}-{}'

###tron info
conf.TRON_URL = 'https://apiasia.tronscan.io:5566/api/token_trc20?contract={}&showAll=1'
