#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import ast
import time
from libs.MyRequest import getRequest
from libs.cmdOptions import initOptions
from settings import conf, mdb


def resultHandler(result):
    newDATA = result['data']
    newDICT = ast.literal_eval(newDATA)
    coins = newDICT['data']
    coins_dict = []
    for d in coins:
        target_token = d['target_token']
        pair = d['pair']
        chain = d['chain']
        token0_symbol = d['token0_symbol']
        token1_symbol = d['token1_symbol']
        pair_name = ("%s/%s") % (token0_symbol, token1_symbol)
        createAT = d['created_at']
        createAT = time.localtime(createAT)
        createTime = time.strftime("%Y-%m-%d %H:%M:%S", createAT)
        myjson = ("('%s','%s','%s','%s','%s')") % (target_token, pair, chain, pair_name, createTime)
        indb = mdb.isInDB(target_token)
        if (indb < 1):
            coins_dict.append(eval(myjson))

        print("合约:%s   币名:%s   已保存数据库:%s    配对:%s          时间:%s    " % (
            target_token, chain, ["是", "否"][indb < 1], pair_name, createTime))

    mdb.save(coins_dict)
    print("\n----- save ok,total=" + str(len(coins_dict)))


##爬取列表
if __name__ == "__main__":
    initOptions()
    result = getRequest(conf.POOL_URL.format(mdb.chain))
    resultHandler(result)
    mdb.close()
