#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import ast
import time
from urllib.parse import urlparse

from libs.MyRequest import getRequest, getHunterInfo
from libs.cmdOptions import initOptions
from settings import conf, mdb


def updateHunterInfo(target_token, website):
    if (website is not None and len(website) > 1):
        if "/" in website:
            result = urlparse(website)
            result = result.netloc.split('.')
            domain = result[-2] + "." + result[-1]
        else:
            domain = website
        print("查询域名:  " + domain)
        hunter_data = getHunterInfo(domain)
        country = hunter_data[0]
        port = hunter_data[1]
        finger = hunter_data[2]
        remarks = hunter_data[3]
        mdb.update(target_token, website, country, port, finger, remarks)
    else:
        remark = "website为空，无hunter查询信息"
        mdb.update(target_token, '', '', '', '', remark)


def resultHandler(reponse, target_token):
    newDICT = ast.literal_eval(reponse['data'])
    result = newDICT['token']
    remark = ''
    website = ''
    if 'appendix' in result.keys():
        appendix_json = ast.literal_eval(result['appendix'])
        website = appendix_json['website']
    updateHunterInfo(target_token, website)
    print("----- %s update ok, %s ----- " % (target_token, remark))


def resultHandler_TRC(reponse, target_token):
    newDICT = reponse['trc20_tokens']
    website=''
    if (len(newDICT) > 0):
        website = newDICT[0]['home_page']
    updateHunterInfo(target_token, website)


def fetchall():
    allData = mdb.getHunter()
    for data in allData:
        try:
            contract = data['target_token']
            chain = data['chain']
            if (chain == 'tron' or chain == 'oec'):
                URL = conf.TRON_URL.format(contract)
                result = getRequest(URL)
                resultHandler_TRC(result, contract)
            else:
                URL = conf.TOKEN_URL.format(contract, chain)
                result = getRequest(URL)
                resultHandler(result, contract)
            time.sleep(2)
        except Exception as e:
            print('fetchall get avi info error:' + str(e))
    print("----- all data check finished ----- ")


if __name__ == "__main__":
    initOptions()
    fetchall()
    mdb.close()
